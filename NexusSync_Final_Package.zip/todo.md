# NexusSync – Project TODO

## Phase 1: Schema & Backend
- [x] Datenbankschema: userProfiles, messages, automationRules, quickReplyTemplates, chatSessions
- [x] DB-Migration mit pnpm db:push
- [x] tRPC-Router: profiles (CRUD + Suche/Filter)
- [x] tRPC-Router: messages (Chat-History, Senden)
- [x] tRPC-Router: automation (Regeln CRUD, Toggle)
- [x] tRPC-Router: quickReplies (Templates CRUD)
- [x] tRPC-Router: analytics (Metriken, Volumen)
- [x] Socket.io-Integration im Server

## Phase 2: Layout & Theme
- [x] NexusLayout (Sidebar kollabierbar, Dark/Light-Mode)
- [x] Dark/Light-Mode-Toggle (Header + Sidebar-Dropdown)
- [x] Globales Theme-System (CSS-Variablen, OKLCH-Farben)
- [x] Responsive Navigation (Mobile-First, Overlay)
- [x] App.tsx Routing für alle Seiten
- [x] Globale Suchfunktion (⌘K) mit Profil-Dropdown

## Phase 3: Dashboard & Analytics
- [x] Analytics-Übersichtsseite (Dashboard Home)
- [x] Aktive-Nutzer-Metriken-Widget (6 KPI-Karten)
- [x] Nachrichtenvolumen-Diagramm (7 Tage AreaChart)
- [x] Profile-nach-Status-Donut-Chart
- [x] Letzte Nachrichten + Neueste Profile Widgets
- [x] Separate Analytics-Seite (30-Tage BarChart)

## Phase 4: Profilverwaltung
- [x] Profilliste mit Such- und Filtersystem (Status, Plattform)
- [x] Profil erstellen (Modal/Dialog mit Validierung)
- [x] Profil bearbeiten (Modal/Dialog)
- [x] Profil löschen (Bestätigungsdialog)
- [x] Profildetail-Seite mit Chat-Link und Automations-Übersicht
- [x] Avatar/Status-Anzeige (Farbkodiert)

## Phase 5: Echtzeit-Chat
- [x] Chat-Interface-Seite mit Profilliste
- [x] Socket.io-Client-Integration (useSocket-Hook)
- [x] Ausziehbare Side-Panels für Chat-Sitzungen
- [x] Schnellantwort-Templates im Chat
- [x] Nachrichtenverlauf laden (tRPC + Socket.io)
- [x] Online-Status-Anzeige

## Phase 6: Automatisierungsmodul
- [x] Automatisierungsregeln-Liste (global + pro Profil)
- [x] Regel erstellen (Zeitplan, Nachricht, Trigger-Typen)
- [x] Toggle-Steuerelemente (aktivieren/deaktivieren)
- [x] Regel bearbeiten und löschen
- [x] Zeitplan-Anzeige (nächste Ausführung)

## Phase 7: RBAC & Tests
- [x] RBAC-Schutz via protectedProcedure für alle kritischen Routen
- [x] Vitest-Tests: 20 Tests für alle Router (Profile, Messages, Automation, Analytics, QuickReplies)
- [x] Alle Tests bestanden (20/20)
- [x] UI-Polish und mobile Responsivität

## Einstellungen
- [x] Schnellantwort-Templates-Verwaltung (CRUD)
- [x] Systemstatus-Anzeige
