import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { analyticsRouter } from "./routers/analytics";
import { automationRouter } from "./routers/automation";
import { messagesRouter } from "./routers/messages";
import { profilesRouter } from "./routers/profiles";
import { quickRepliesRouter } from "./routers/quickReplies";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  profiles: profilesRouter,
  messages: messagesRouter,
  automation: automationRouter,
  quickReplies: quickRepliesRouter,
  analytics: analyticsRouter,
});

export type AppRouter = typeof appRouter;
