import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB ─────────────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  upsertUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  getProfiles: vi.fn().mockResolvedValue({ profiles: [], total: 0 }),
  getProfileById: vi.fn().mockResolvedValue(null),
  createProfile: vi.fn().mockResolvedValue({ insertId: 1 }),
  updateProfile: vi.fn().mockResolvedValue({ id: 1, displayName: "Updated" }),
  deleteProfile: vi.fn().mockResolvedValue(undefined),
  getMessagesByProfile: vi.fn().mockResolvedValue([]),
  createMessage: vi.fn().mockResolvedValue({ insertId: 1 }),
  markMessagesRead: vi.fn().mockResolvedValue(undefined),
  getRecentMessages: vi.fn().mockResolvedValue([]),
  getOrCreateChatSession: vi.fn().mockResolvedValue({ id: 1, profileId: 1, adminId: 1 }),
  getQuickReplies: vi.fn().mockResolvedValue([]),
  createQuickReply: vi.fn().mockResolvedValue(undefined),
  updateQuickReply: vi.fn().mockResolvedValue(undefined),
  deleteQuickReply: vi.fn().mockResolvedValue(undefined),
  incrementQuickReplyUsage: vi.fn().mockResolvedValue(undefined),
  getAutomationRules: vi.fn().mockResolvedValue([]),
  getAllAutomationRules: vi.fn().mockResolvedValue([]),
  createAutomationRule: vi.fn().mockResolvedValue(undefined),
  updateAutomationRule: vi.fn().mockResolvedValue(undefined),
  deleteAutomationRule: vi.fn().mockResolvedValue(undefined),
  toggleAutomationRule: vi.fn().mockResolvedValue(undefined),
  getAnalytics: vi.fn().mockResolvedValue({
    totalProfiles: 5,
    activeProfiles: 3,
    totalMessages: 42,
    todayMessages: 7,
    onlineProfiles: 2,
    activeRules: 1,
  }),
  getMessageVolumeByDay: vi.fn().mockResolvedValue([]),
  getProfilesByStatus: vi.fn().mockResolvedValue([]),
}));

// ─── Test Context Factory ─────────────────────────────────────────────────────
function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-open-id",
      name: "Admin User",
      email: "admin@nexussync.test",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
      cookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

// ─── Auth Tests ───────────────────────────────────────────────────────────────
describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const ctx = createAdminContext();
    const clearedCookies: string[] = [];
    ctx.res.clearCookie = (name: string) => { clearedCookies.push(name); };

    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();

    expect(result.success).toBe(true);
    expect(clearedCookies).toHaveLength(1);
  });

  it("returns current user via auth.me", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();

    expect(user?.email).toBe("admin@nexussync.test");
    expect(user?.role).toBe("admin");
  });
});

// ─── Profiles Tests ───────────────────────────────────────────────────────────
describe("profiles", () => {
  it("lists profiles with empty result", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.profiles.list({});

    expect(result).toHaveProperty("profiles");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.profiles)).toBe(true);
  });

  it("creates a profile successfully", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.profiles.create({
      displayName: "Test Profil",
      username: "test_profil",
      email: "test@example.com",
      status: "active",
    });

    expect(result.success).toBe(true);
  });

  it("deletes a profile successfully", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.profiles.delete({ id: 1 });

    expect(result.success).toBe(true);
  });

  it("rejects unauthenticated profile list", async () => {
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);

    await expect(caller.profiles.list({})).rejects.toThrow();
  });
});

// ─── Messages Tests ───────────────────────────────────────────────────────────
describe("messages", () => {
  it("fetches messages by profile", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.messages.byProfile({ profileId: 1 });

    expect(Array.isArray(result)).toBe(true);
  });

  it("sends a message successfully", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.messages.send({
      profileId: 1,
      content: "Hallo, das ist eine Testnachricht",
    });

    expect(result.success).toBe(true);
  });

  it("fetches recent messages", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.messages.recent({ limit: 10 });

    expect(Array.isArray(result)).toBe(true);
  });
});

// ─── Automation Tests ─────────────────────────────────────────────────────────
describe("automation", () => {
  it("lists all automation rules", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.automation.all();

    expect(Array.isArray(result)).toBe(true);
  });

  it("creates an automation rule", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.automation.create({
      profileId: 1,
      name: "Tägliche Begrüßung",
      triggerType: "scheduled",
      triggerValue: "0 9 * * 1-5",
      messageContent: "Guten Morgen! Wie kann ich helfen?",
      isActive: true,
    });

    expect(result.success).toBe(true);
  });

  it("toggles automation rule", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.automation.toggle({ id: 1, isActive: false });

    expect(result.success).toBe(true);
  });

  it("deletes an automation rule", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.automation.delete({ id: 1 });

    expect(result.success).toBe(true);
  });
});

// ─── Analytics Tests ──────────────────────────────────────────────────────────
describe("analytics", () => {
  it("returns analytics overview", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.analytics.overview();

    expect(result).not.toBeNull();
    expect(result).toHaveProperty("totalProfiles");
    expect(result).toHaveProperty("totalMessages");
    expect(result).toHaveProperty("activeRules");
    expect(result?.totalProfiles).toBe(5);
  });

  it("returns message volume data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.analytics.messageVolume({ days: 7 });

    expect(Array.isArray(result)).toBe(true);
  });

  it("returns profiles by status", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.analytics.profilesByStatus();

    expect(Array.isArray(result)).toBe(true);
  });
});

// ─── Quick Replies Tests ──────────────────────────────────────────────────────
describe("quickReplies", () => {
  it("lists quick replies", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.quickReplies.list();

    expect(Array.isArray(result)).toBe(true);
  });

  it("creates a quick reply", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.quickReplies.create({
      title: "Begrüßung",
      content: "Hallo! Wie kann ich Ihnen helfen?",
      category: "Allgemein",
    });

    expect(result.success).toBe(true);
  });

  it("deletes a quick reply", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.quickReplies.delete({ id: 1 });

    expect(result.success).toBe(true);
  });
});
