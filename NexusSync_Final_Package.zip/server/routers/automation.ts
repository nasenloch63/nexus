import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createAutomationRule,
  deleteAutomationRule,
  getAllAutomationRules,
  getAutomationRules,
  toggleAutomationRule,
  updateAutomationRule,
} from "../db";

export const automationRouter = router({
  byProfile: protectedProcedure
    .input(z.object({ profileId: z.number() }))
    .query(({ input }) => getAutomationRules(input.profileId)),

  all: protectedProcedure.query(() => getAllAutomationRules()),

  create: protectedProcedure
    .input(
      z.object({
        profileId: z.number(),
        name: z.string().min(1).max(128),
        description: z.string().optional(),
        triggerType: z.enum(["scheduled", "keyword", "inactivity", "welcome"]),
        triggerValue: z.string().optional(),
        messageContent: z.string().min(1),
        isActive: z.boolean().optional(),
        nextTrigger: z.date().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await createAutomationRule({ ...input, createdBy: ctx.user.id });
      return { success: true };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(128).optional(),
        description: z.string().optional(),
        triggerType: z.enum(["scheduled", "keyword", "inactivity", "welcome"]).optional(),
        triggerValue: z.string().optional(),
        messageContent: z.string().min(1).optional(),
        isActive: z.boolean().optional(),
        nextTrigger: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await updateAutomationRule(id, data);
      return { success: true };
    }),

  toggle: protectedProcedure
    .input(z.object({ id: z.number(), isActive: z.boolean() }))
    .mutation(async ({ input }) => {
      await toggleAutomationRule(input.id, input.isActive);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteAutomationRule(input.id);
      return { success: true };
    }),
});
