import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createQuickReply,
  deleteQuickReply,
  getQuickReplies,
  incrementQuickReplyUsage,
  updateQuickReply,
} from "../db";

export const quickRepliesRouter = router({
  list: protectedProcedure.query(({ ctx }) => getQuickReplies(ctx.user.id)),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(128),
        content: z.string().min(1),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await createQuickReply({ ...input, createdBy: ctx.user.id });
      return { success: true };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(128).optional(),
        content: z.string().min(1).optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await updateQuickReply(id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteQuickReply(input.id);
      return { success: true };
    }),

  use: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await incrementQuickReplyUsage(input.id);
      return { success: true };
    }),
});
