import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createMessage,
  getMessagesByProfile,
  getOrCreateChatSession,
  getRecentMessages,
  markMessagesRead,
} from "../db";

export const messagesRouter = router({
  byProfile: protectedProcedure
    .input(
      z.object({
        profileId: z.number(),
        limit: z.number().min(1).max(100).optional(),
        offset: z.number().min(0).optional(),
      })
    )
    .query(({ input }) =>
      getMessagesByProfile(input.profileId, input.limit ?? 50, input.offset ?? 0)
    ),

  recent: protectedProcedure
    .input(z.object({ limit: z.number().min(1).max(50).optional() }))
    .query(({ input }) => getRecentMessages(input.limit ?? 20)),

  send: protectedProcedure
    .input(
      z.object({
        profileId: z.number(),
        content: z.string().min(1),
        messageType: z.enum(["text", "image", "file", "template"]).optional(),
        senderType: z.enum(["admin", "user", "system", "automated"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await createMessage({
        profileId: input.profileId,
        senderId: ctx.user.id,
        content: input.content,
        messageType: input.messageType ?? "text",
        senderType: input.senderType ?? "admin",
      });
      return { success: true };
    }),

  markRead: protectedProcedure
    .input(z.object({ profileId: z.number() }))
    .mutation(async ({ input }) => {
      await markMessagesRead(input.profileId);
      return { success: true };
    }),

  getSession: protectedProcedure
    .input(z.object({ profileId: z.number() }))
    .query(({ input, ctx }) => getOrCreateChatSession(input.profileId, ctx.user.id)),
});
