import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getAnalytics, getMessageVolumeByDay, getProfilesByStatus } from "../db";

export const analyticsRouter = router({
  overview: protectedProcedure.query(() => getAnalytics()),

  messageVolume: protectedProcedure
    .input(z.object({ days: z.number().min(1).max(30).optional() }))
    .query(({ input }) => getMessageVolumeByDay(input.days ?? 7)),

  profilesByStatus: protectedProcedure.query(() => getProfilesByStatus()),
});
