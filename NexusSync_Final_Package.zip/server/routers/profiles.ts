import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createProfile,
  deleteProfile,
  getProfileById,
  getProfiles,
  updateProfile,
} from "../db";

export const profilesRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        search: z.string().optional(),
        status: z.string().optional(),
        platform: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
        offset: z.number().min(0).optional(),
      })
    )
    .query(({ input }) => getProfiles(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const profile = await getProfileById(input.id);
      if (!profile) throw new TRPCError({ code: "NOT_FOUND", message: "Profil nicht gefunden" });
      return profile;
    }),

  create: protectedProcedure
    .input(
      z.object({
        displayName: z.string().min(1).max(128),
        username: z.string().min(2).max(64).regex(/^[a-zA-Z0-9_.-]+$/),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        bio: z.string().optional(),
        platform: z.string().optional(),
        tags: z.string().optional(),
        avatarUrl: z.string().optional(),
        status: z.enum(["active", "inactive", "banned"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await createProfile({
        ...input,
        email: input.email || null,
        createdBy: ctx.user.id,
      });
      return { success: true };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        displayName: z.string().min(1).max(128).optional(),
        username: z.string().min(2).max(64).optional(),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        bio: z.string().optional(),
        platform: z.string().optional(),
        tags: z.string().optional(),
        avatarUrl: z.string().optional(),
        status: z.enum(["active", "inactive", "banned"]).optional(),
        isOnline: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const updated = await updateProfile(id, {
        ...data,
        email: data.email || null,
      });
      return updated;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteProfile(input.id);
      return { success: true };
    }),
});
