import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { Server as SocketIOServer } from "socket.io";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { createMessage, getMessagesByProfile } from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) return port;
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // ── Socket.io Setup ──────────────────────────────────────────────────────
  const io = new SocketIOServer(server, {
    cors: { origin: "*", methods: ["GET", "POST"] },
    path: "/api/socket.io",
  });

  // Track online users per profile room
  const profileRooms = new Map<string, Set<string>>();

  io.on("connection", (socket) => {
    console.log(`[Socket.io] Client connected: ${socket.id}`);

    // Join a profile chat room
    socket.on("join:profile", (profileId: number) => {
      const room = `profile:${profileId}`;
      socket.join(room);
      if (!profileRooms.has(room)) profileRooms.set(room, new Set());
      profileRooms.get(room)!.add(socket.id);
      io.to(room).emit("room:users", profileRooms.get(room)!.size);
    });

    // Leave a profile chat room
    socket.on("leave:profile", (profileId: number) => {
      const room = `profile:${profileId}`;
      socket.leave(room);
      if (profileRooms.has(room)) {
        profileRooms.get(room)!.delete(socket.id);
        io.to(room).emit("room:users", profileRooms.get(room)!.size);
      }
    });

    // Send a message
    socket.on(
      "message:send",
      async (data: {
        profileId: number;
        content: string;
        senderId?: number;
        senderType?: "admin" | "user" | "system" | "automated";
      }) => {
        try {
          await createMessage({
            profileId: data.profileId,
            senderId: data.senderId ?? null,
            content: data.content,
            senderType: data.senderType ?? "admin",
            messageType: "text",
          });

          const room = `profile:${data.profileId}`;
          io.to(room).emit("message:new", {
            profileId: data.profileId,
            content: data.content,
            senderType: data.senderType ?? "admin",
            createdAt: new Date().toISOString(),
          });
        } catch (err) {
          console.error("[Socket.io] Error saving message:", err);
          socket.emit("message:error", { error: "Nachricht konnte nicht gespeichert werden" });
        }
      }
    );

    // Typing indicator
    socket.on("typing:start", (profileId: number) => {
      socket.to(`profile:${profileId}`).emit("typing:start", { profileId });
    });
    socket.on("typing:stop", (profileId: number) => {
      socket.to(`profile:${profileId}`).emit("typing:stop", { profileId });
    });

    socket.on("disconnect", () => {
      console.log(`[Socket.io] Client disconnected: ${socket.id}`);
      profileRooms.forEach((sockets, room) => {
        if (sockets.has(socket.id)) {
          sockets.delete(socket.id);
          io.to(room).emit("room:users", sockets.size);
        }
      });
    });
  });

  // Make io available globally for automation triggers
  (global as Record<string, unknown>).nexusIO = io;

  // ── Express Middleware ───────────────────────────────────────────────────
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerOAuthRoutes(app);

  app.use(
    "/api/trpc",
    createExpressMiddleware({ router: appRouter, createContext })
  );

  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
