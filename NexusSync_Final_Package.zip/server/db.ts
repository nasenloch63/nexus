import { and, desc, eq, ilike, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertAutomationRule,
  InsertChatSession,
  InsertMessage,
  InsertQuickReplyTemplate,
  InsertUser,
  InsertUserProfile,
  automationRules,
  chatSessions,
  messages,
  quickReplyTemplates,
  userProfiles,
  users,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

// ─── User Profiles ────────────────────────────────────────────────────────────
export async function getProfiles(opts: {
  search?: string;
  status?: string;
  platform?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return { profiles: [], total: 0 };

  const conditions = [];
  if (opts.search) {
    conditions.push(
      or(
        like(userProfiles.displayName, `%${opts.search}%`),
        like(userProfiles.username, `%${opts.search}%`),
        like(userProfiles.email, `%${opts.search}%`)
      )
    );
  }
  if (opts.status && opts.status !== "all") {
    conditions.push(eq(userProfiles.status, opts.status as "active" | "inactive" | "banned"));
  }
  if (opts.platform && opts.platform !== "all") {
    conditions.push(eq(userProfiles.platform, opts.platform));
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const limit = opts.limit ?? 20;
  const offset = opts.offset ?? 0;

  const [profileList, countResult] = await Promise.all([
    db
      .select()
      .from(userProfiles)
      .where(where)
      .orderBy(desc(userProfiles.updatedAt))
      .limit(limit)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(userProfiles).where(where),
  ]);

  return { profiles: profileList, total: Number(countResult[0]?.count ?? 0) };
}

export async function getProfileById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userProfiles).where(eq(userProfiles.id, id)).limit(1);
  return result[0];
}

export async function createProfile(data: InsertUserProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(userProfiles).values(data);
  return result;
}

export async function updateProfile(id: number, data: Partial<InsertUserProfile>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(userProfiles).set(data).where(eq(userProfiles.id, id));
  return getProfileById(id);
}

export async function deleteProfile(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(userProfiles).where(eq(userProfiles.id, id));
}

// ─── Messages ─────────────────────────────────────────────────────────────────
export async function getMessagesByProfile(profileId: number, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(messages)
    .where(eq(messages.profileId, profileId))
    .orderBy(desc(messages.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function createMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(messages).values(data);
  // Increment totalMessages on profile
  await db
    .update(userProfiles)
    .set({ totalMessages: sql`${userProfiles.totalMessages} + 1` })
    .where(eq(userProfiles.id, data.profileId));
  return result;
}

export async function markMessagesRead(profileId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(messages)
    .set({ isRead: true })
    .where(and(eq(messages.profileId, profileId), eq(messages.isRead, false)));
}

export async function getRecentMessages(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).orderBy(desc(messages.createdAt)).limit(limit);
}

// ─── Quick Reply Templates ────────────────────────────────────────────────────
export async function getQuickReplies(createdBy: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(quickReplyTemplates)
    .where(eq(quickReplyTemplates.createdBy, createdBy))
    .orderBy(desc(quickReplyTemplates.usageCount));
}

export async function createQuickReply(data: InsertQuickReplyTemplate) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(quickReplyTemplates).values(data);
}

export async function updateQuickReply(id: number, data: Partial<InsertQuickReplyTemplate>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(quickReplyTemplates).set(data).where(eq(quickReplyTemplates.id, id));
}

export async function deleteQuickReply(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(quickReplyTemplates).where(eq(quickReplyTemplates.id, id));
}

export async function incrementQuickReplyUsage(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(quickReplyTemplates)
    .set({ usageCount: sql`${quickReplyTemplates.usageCount} + 1` })
    .where(eq(quickReplyTemplates.id, id));
}

// ─── Automation Rules ─────────────────────────────────────────────────────────
export async function getAutomationRules(profileId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(automationRules)
    .where(eq(automationRules.profileId, profileId))
    .orderBy(desc(automationRules.createdAt));
}

export async function getAllAutomationRules() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(automationRules).orderBy(desc(automationRules.createdAt));
}

export async function createAutomationRule(data: InsertAutomationRule) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(automationRules).values(data);
}

export async function updateAutomationRule(id: number, data: Partial<InsertAutomationRule>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(automationRules).set(data).where(eq(automationRules.id, id));
}

export async function deleteAutomationRule(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(automationRules).where(eq(automationRules.id, id));
}

export async function toggleAutomationRule(id: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(automationRules).set({ isActive }).where(eq(automationRules.id, id));
}

// ─── Chat Sessions ────────────────────────────────────────────────────────────
export async function getOrCreateChatSession(profileId: number, adminId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db
    .select()
    .from(chatSessions)
    .where(and(eq(chatSessions.profileId, profileId), eq(chatSessions.adminId, adminId)))
    .limit(1);
  if (existing[0]) return existing[0];
  await db.insert(chatSessions).values({ profileId, adminId });
  const created = await db
    .select()
    .from(chatSessions)
    .where(and(eq(chatSessions.profileId, profileId), eq(chatSessions.adminId, adminId)))
    .limit(1);
  return created[0];
}

// ─── Analytics ────────────────────────────────────────────────────────────────
export async function getAnalytics() {
  const db = await getDb();
  if (!db) return null;

  const [
    totalProfiles,
    activeProfiles,
    totalMessages,
    todayMessages,
    onlineProfiles,
    activeRules,
  ] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(userProfiles),
    db
      .select({ count: sql<number>`count(*)` })
      .from(userProfiles)
      .where(eq(userProfiles.status, "active")),
    db.select({ count: sql<number>`count(*)` }).from(messages),
    db
      .select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(sql`DATE(${messages.createdAt}) = CURDATE()`),
    db
      .select({ count: sql<number>`count(*)` })
      .from(userProfiles)
      .where(eq(userProfiles.isOnline, true)),
    db
      .select({ count: sql<number>`count(*)` })
      .from(automationRules)
      .where(eq(automationRules.isActive, true)),
  ]);

  return {
    totalProfiles: Number(totalProfiles[0]?.count ?? 0),
    activeProfiles: Number(activeProfiles[0]?.count ?? 0),
    totalMessages: Number(totalMessages[0]?.count ?? 0),
    todayMessages: Number(todayMessages[0]?.count ?? 0),
    onlineProfiles: Number(onlineProfiles[0]?.count ?? 0),
    activeRules: Number(activeRules[0]?.count ?? 0),
  };
}

export async function getMessageVolumeByDay(days = 7) {
  const db = await getDb();
  if (!db) return [];
  const result = await db.execute(
    sql`SELECT DATE(createdAt) as date, COUNT(*) as count 
        FROM messages 
        WHERE createdAt >= DATE_SUB(NOW(), INTERVAL ${days} DAY)
        GROUP BY DATE(createdAt) 
        ORDER BY date ASC`
  );
  return (result[0] as unknown as Array<{ date: string; count: number }>).map((r) => ({
    date: String(r.date),
    count: Number(r.count),
  }));
}

export async function getProfilesByStatus() {
  const db = await getDb();
  if (!db) return [];
  const result = await db.execute(
    sql`SELECT status, COUNT(*) as count FROM user_profiles GROUP BY status`
  );
  return (result[0] as unknown as Array<{ status: string; count: number }>).map((r) => ({
    status: String(r.status),
    count: Number(r.count),
  }));
}
