# NexusSync - Vollständige Deployment-Anleitung

## Was ist NexusSync?

NexusSync ist ein fortgeschrittenes Admin-Dashboard für Multi-Profil-Verwaltung mit folgenden Features:

- **Multi-Profil-Verwaltung** - CRUD-Operationen für Benutzerprofile
- **Echtzeit-Chat** - Socket.io basierter Messaging
- **Automatisierte Nachrichten** - Geplante und automatisierte Antworten
- **Analytics-Dashboard** - Recharts-basierte Diagramme
- **Dark/Light-Mode** - Umschaltbares Theme
- **Globale Suche** - Schnellsuche mit ⌘K
- **RBAC** - Rollenbasierte Zugriffskontrolle
- **Responsive Design** - Mobile-first UI

---

## Schnellstart (Lokal)

### 1. Abhängigkeiten installieren

```bash
cd nexussync
npm install
# oder
pnpm install
```

### 2. Umgebungsvariablen konfigurieren

Kopiere `.env.local.example` zu `.env.local` und fülle die Werte aus:

```env
# Datenbank (MySQL/MariaDB - z.B. PlanetScale, Turso, eigene MySQL)
DATABASE_URL=mysql://username:password@host:port/database

# JWT Secret (mindestens 32 Zeichen)
JWT_SECRET=dein_geheimer_schluessel_mindestens_32_zeichen

# OAuth Konfiguration (Manus Platform)
VITE_APP_ID=deine_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# Owner Konfiguration
OWNER_NAME=Admin
OWNER_OPEN_ID=deine_owner_open_id
```

### 3. Datenbankschema erstellen

```bash
npm run db:push
```

### 4. Entwicklungsserver starten

```bash
npm run dev
```

Öffne http://localhost:3000

---

## Vercel Deployment

### Option A: Direkt über Vercel CLI

1. **Vercel CLI installieren:**
```bash
npm i -g vercel
```

2. **Im Projektverzeichnis:**
```bash
vercel login
vercel --prod
```

3. **Umgebungsvariablen in Vercel Dashboard hinzufügen:**
- Gehe zu deinem Projekt → Settings → Environment Variables
- Füge alle Variablen aus `.env.local` hinzu

### Option B: Über GitHub

1. **Projekt zu GitHub pushen:**
```bash
git init
git add .
git commit -m "NexusSync v1.0"
git branch -M main
git remote add origin https://github.com/username/nexussync.git
git push -u origin main
```

2. **Bei Vercel importieren:**
- Gehe zu https://vercel.com
- "Import Project" → GitHub Repository auswählen
- Framework Preset: Other
- Build Command: `npm run build`
- Output Directory: `dist`

3. **Umgebungsvariablen konfigurieren:**
- Im Vercel Dashboard → Settings → Environment Variables
- Alle Variablen aus `.env.local` hinzufügen

---

## API-Konfiguration (Schritt-für-Schritt)

### 1. MongoDB Atlas (oder MySQL)

**Option A: MongoDB Atlas**
1. Erstelle Account auf https://www.mongodb.com/cloud/atlas
2. Neues Cluster erstellen (Free Tier)
3. Database User anlegen
4. Network Access konfigurieren (0.0.0.0/0 für Vercel)
5. Connection String kopieren

**Option B: MySQL (empfohlen für dieses Projekt)**
Das Projekt nutzt Drizzle ORM mit MySQL. Empfohlene Anbieter:
- PlanetScale (MySQL-kompatibel)
- Turso (LibSQL)
- AWS RDS
- Eigenen MySQL Server

### 2. OAuth konfigurieren (Manus Platform)

Das Projekt verwendet Manus OAuth für Authentication. Du brauchst:

1. **Manus Account:** https://portal.manus.im
2. **App erstellen:** Neue App im Portal anlegen
3. **App ID kopieren:** Aus den App-Einstellungen
4. **Redirect URI:** `https://deine-domain.com/api/oauth/callback`

### 3. Umgebungsvariablen Übersicht

| Variable | Beschreibung | Beispiel |
|----------|--------------|----------|
| DATABASE_URL | MySQL Connection String | `mysql://user:pass@host:3306/db` |
| JWT_SECRET | Session Secret (min 32 chars) | `openssl rand -base64 32` |
| VITE_APP_ID | Manus App ID | `app_xxxxxxxxxxxx` |
| OAUTH_SERVER_URL | Manus API URL | `https://api.manus.im` |
| VITE_OAUTH_PORTAL_URL | Manus Portal URL | `https://portal.manus.im` |
| OWNER_NAME | Admin Name | `Admin` |
| OWNER_OPEN_ID | Owner OpenID | `owner_xxxxxxxx` |

---

## Bekannte Probleme und Lösungen

### Build Fehler: zod version
**Problem:** `zod/v4/core` kann nicht gefunden werden
**Lösung:** Version auf ^3.24.0 setzen (in package.json)

### CSS Warning: @import Reihenfolge
**Problem:** `@import` muss vor allen anderen Regeln kommen
**Lösung:** Bereits gefixt in `client/index.css`

### Peer Dependency Warning
**Problem:** `@builder.io/vite-plugin-jsx-loc` will Vite 4 oder 5
**Lösung:** Kann ignoriert werden, funktioniert auch mit Vite 7

---

## Projektstruktur

```
nexussync/
├── client/                 # React Frontend
│   ├── src/
│   │   ├── pages/        # Seiten (Dashboard, Profiles, Chat, etc.)
│   │   ├── components/   # UI Komponenten
│   │   ├── contexts/     # Theme Context
│   │   └── lib/          # tRPC Client
│   └── public/           # Statische Assets
├── server/                # Express Backend
│   ├── routers/          # t│   │RPC Router
   ├── profiles.ts
│   │   ├── messages.ts
│   │   ├── automation.ts
│   │   ├── quickReplies.ts
│   │   └── analytics.ts
│   └── _core/            # Framework Code
│       ├── oauth.ts
│       ├── sdk.ts
│       └── context.ts
├── drizzle/               # Datenbank Schema
├── vercel.json           # Vercel Konfiguration
├── package.json
└── .env.local.example
```

---

## Verfügbare Scripts

| Befehl | Beschreibung |
|--------|--------------|
| `npm run dev` | Entwicklungsserver starten |
| `npm run build` | Produktions-Build erstellen |
| `npm start` | Produktions-Server starten |
| `npm run db:push` | Datenbankschema migrieren |
| `npm run test` | Tests ausführen |
| `npm run check` | TypeScript-Check |

---

## Support

Bei Problemen:

1. **Logs prüfen:** `npm run dev` zeigt Fehler in der Konsole
2. **Datenbank-Verbindung:** `DATABASE_URL` muss korrekt sein
3. **OAuth-Konfiguration:** Alle Manus-Variablen müssen gesetzt sein

---

## Lizenz

MIT License - Für private und kommerzielle Nutzung freigegeben.

---

**Viel Erfolg mit NexusSync!**
