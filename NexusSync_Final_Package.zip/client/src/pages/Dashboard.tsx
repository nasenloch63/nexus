import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import {
  Activity,
  ArrowUpRight,
  Bot,
  MessageSquare,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { useMemo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

function KpiCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  color,
  loading,
}: {
  title: string;
  value: number | string;
  subtitle: string;
  icon: React.ElementType;
  trend?: string;
  color: string;
  loading?: boolean;
}) {
  return (
    <Card className="relative overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1 min-w-0">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
              {title}
            </p>
            {loading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="text-3xl font-bold text-foreground">{value}</p>
            )}
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          </div>
          <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", color)}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        {trend && (
          <div className="mt-3 flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
            <ArrowUpRight className="w-3 h-3" />
            <span>{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: overview, isLoading: overviewLoading } = trpc.analytics.overview.useQuery();
  const { data: volumeData, isLoading: volumeLoading } = trpc.analytics.messageVolume.useQuery({ days: 7 });
  const { data: statusData } = trpc.analytics.profilesByStatus.useQuery();
  const { data: recentMessages } = trpc.messages.recent.useQuery({ limit: 8 });
  const { data: profilesData } = trpc.profiles.list.useQuery({ limit: 5 });

  const chartData = useMemo(() => {
    if (!volumeData) return [];
    return volumeData.map((d) => ({
      date: new Date(d.date).toLocaleDateString("de-DE", { weekday: "short", day: "numeric" }),
      Nachrichten: d.count,
    }));
  }, [volumeData]);

  const pieData = useMemo(() => {
    if (!statusData) return [];
    const colors: Record<string, string> = {
      active: "#22c55e",
      inactive: "#f59e0b",
      banned: "#ef4444",
    };
    const labels: Record<string, string> = {
      active: "Aktiv",
      inactive: "Inaktiv",
      banned: "Gesperrt",
    };
    return statusData.map((d) => ({
      name: labels[d.status] ?? d.status,
      value: d.count,
      color: colors[d.status] ?? "#6b7280",
    }));
  }, [statusData]);

  return (
    <NexusLayout
      title="Dashboard"
      subtitle="Willkommen bei NexusSync — Ihre Übersicht auf einen Blick"
    >
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          <KpiCard
            title="Profile"
            value={overview?.totalProfiles ?? 0}
            subtitle="Gesamt registriert"
            icon={Users}
            color="bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400"
            loading={overviewLoading}
          />
          <KpiCard
            title="Aktiv"
            value={overview?.activeProfiles ?? 0}
            subtitle="Aktive Profile"
            icon={Activity}
            color="bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400"
            loading={overviewLoading}
          />
          <KpiCard
            title="Online"
            value={overview?.onlineProfiles ?? 0}
            subtitle="Gerade online"
            icon={Zap}
            color="bg-violet-100 text-violet-600 dark:bg-violet-900/30 dark:text-violet-400"
            loading={overviewLoading}
          />
          <KpiCard
            title="Nachrichten"
            value={overview?.totalMessages ?? 0}
            subtitle="Gesamt gesendet"
            icon={MessageSquare}
            color="bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400"
            loading={overviewLoading}
          />
          <KpiCard
            title="Heute"
            value={overview?.todayMessages ?? 0}
            subtitle="Nachrichten heute"
            icon={TrendingUp}
            color="bg-pink-100 text-pink-600 dark:bg-pink-900/30 dark:text-pink-400"
            loading={overviewLoading}
          />
          <KpiCard
            title="Regeln"
            value={overview?.activeRules ?? 0}
            subtitle="Aktive Automationen"
            icon={Bot}
            color="bg-cyan-100 text-cyan-600 dark:bg-cyan-900/30 dark:text-cyan-400"
            loading={overviewLoading}
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Message Volume Chart */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Nachrichtenvolumen (7 Tage)</CardTitle>
                <Badge variant="secondary" className="text-xs">Live</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {volumeLoading ? (
                <Skeleton className="h-48 w-full" />
              ) : chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="msgGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.62 0.22 264)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.62 0.22 264)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                    <YAxis tick={{ fontSize: 11 }} className="fill-muted-foreground" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--color-popover)",
                        border: "1px solid var(--color-border)",
                        borderRadius: "8px",
                        fontSize: "12px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="Nachrichten"
                      stroke="oklch(0.62 0.22 264)"
                      strokeWidth={2}
                      fill="url(#msgGradient)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                  Noch keine Nachrichtendaten vorhanden
                </div>
              )}
            </CardContent>
          </Card>

          {/* Profile Status Pie */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">Profile nach Status</CardTitle>
            </CardHeader>
            <CardContent>
              {pieData.length > 0 ? (
                <div className="space-y-3">
                  <ResponsiveContainer width="100%" height={140}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={65}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--color-popover)",
                          border: "1px solid var(--color-border)",
                          borderRadius: "8px",
                          fontSize: "12px",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-1.5">
                    {pieData.map((d) => (
                      <div key={d.name} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: d.color }}
                          />
                          <span className="text-muted-foreground">{d.name}</span>
                        </div>
                        <span className="font-medium">{d.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                  Keine Profile vorhanden
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Recent Messages */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Letzte Nachrichten</CardTitle>
                <Link href="/chat">
                  <Button variant="ghost" size="sm" className="text-xs h-7 gap-1">
                    Alle anzeigen <ArrowUpRight className="w-3 h-3" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {recentMessages && recentMessages.length > 0 ? (
                recentMessages.slice(0, 5).map((msg) => (
                  <div
                    key={msg.id}
                    className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium text-primary shrink-0 mt-0.5">
                      {msg.senderType === "admin" ? "A" : msg.senderType === "automated" ? "B" : "U"}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="secondary"
                          className="text-xs py-0 px-1.5 h-4 capitalize"
                        >
                          {msg.senderType}
                        </Badge>
                        <span className="text-xs text-muted-foreground ml-auto">
                          {new Date(msg.createdAt).toLocaleTimeString("de-DE", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      <p className="text-sm text-foreground truncate mt-0.5">{msg.content}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-6">
                  Noch keine Nachrichten vorhanden
                </p>
              )}
            </CardContent>
          </Card>

          {/* Recent Profiles */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Neueste Profile</CardTitle>
                <Link href="/profiles">
                  <Button variant="ghost" size="sm" className="text-xs h-7 gap-1">
                    Alle anzeigen <ArrowUpRight className="w-3 h-3" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {profilesData && profilesData.profiles.length > 0 ? (
                profilesData.profiles.slice(0, 5).map((profile) => (
                  <Link key={profile.id} href={`/profiles/${profile.id}`}>
                    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                      <div className="relative shrink-0">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                          {profile.displayName[0].toUpperCase()}
                        </div>
                        {profile.isOnline && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-background" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{profile.displayName}</p>
                        <p className="text-xs text-muted-foreground truncate">@{profile.username}</p>
                      </div>
                      <div className="shrink-0">
                        <span
                          className={cn(
                            "text-xs px-2 py-0.5 rounded-full font-medium",
                            profile.status === "active" && "status-active",
                            profile.status === "inactive" && "status-inactive",
                            profile.status === "banned" && "status-banned"
                          )}
                        >
                          {profile.status === "active"
                            ? "Aktiv"
                            : profile.status === "inactive"
                            ? "Inaktiv"
                            : "Gesperrt"}
                        </span>
                      </div>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="text-center py-6 space-y-2">
                  <p className="text-sm text-muted-foreground">Noch keine Profile vorhanden</p>
                  <Link href="/profiles">
                    <Button size="sm" variant="outline" className="text-xs">
                      Erstes Profil erstellen
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </NexusLayout>
  );
}
