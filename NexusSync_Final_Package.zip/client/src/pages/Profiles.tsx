import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Edit,
  Filter,
  MessageSquare,
  MoreHorizontal,
  Plus,
  Search,
  Trash2,
  Users,
  X,
  Bot,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link } from "wouter";
import { z } from "zod";
import { toast } from "sonner";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const profileSchema = z.object({
  displayName: z.string().min(1, "Name erforderlich").max(128),
  username: z
    .string()
    .min(2, "Mind. 2 Zeichen")
    .max(64)
    .regex(/^[a-zA-Z0-9_.-]+$/, "Nur Buchstaben, Zahlen, _, . erlaubt"),
  email: z.string().email("Ungültige E-Mail").optional().or(z.literal("")),
  phone: z.string().optional(),
  bio: z.string().optional(),
  platform: z.string().optional(),
  status: z.enum(["active", "inactive", "banned"]).optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

const PLATFORMS = ["general", "telegram", "whatsapp", "instagram", "twitter", "facebook", "discord"];
const STATUS_LABELS: Record<string, string> = {
  active: "Aktiv",
  inactive: "Inaktiv",
  banned: "Gesperrt",
};

export default function Profiles() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [platformFilter, setPlatformFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [createOpen, setCreateOpen] = useState(false);
  const [editProfile, setEditProfile] = useState<number | null>(null);
  const [deleteProfile, setDeleteProfile] = useState<{ id: number; name: string } | null>(null);

  const utils = trpc.useUtils();

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(t);
  }, [search]);

  const { data, isLoading } = trpc.profiles.list.useQuery({
    search: debouncedSearch || undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
    platform: platformFilter !== "all" ? platformFilter : undefined,
    limit: 12,
    offset: page * 12,
  });

  const createMutation = trpc.profiles.create.useMutation({
    onSuccess: () => {
      utils.profiles.list.invalidate();
      utils.analytics.overview.invalidate();
      setCreateOpen(false);
      toast.success("Profil erfolgreich erstellt");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.profiles.update.useMutation({
    onSuccess: () => {
      utils.profiles.list.invalidate();
      setEditProfile(null);
      toast.success("Profil aktualisiert");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.profiles.delete.useMutation({
    onSuccess: () => {
      utils.profiles.list.invalidate();
      utils.analytics.overview.invalidate();
      setDeleteProfile(null);
      toast.success("Profil gelöscht");
    },
    onError: (e) => toast.error(e.message),
  });

  const profiles = data?.profiles ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / 12);

  return (
    <NexusLayout title="Profile" subtitle={`${total} Profile verwaltet`}>
      <div className="space-y-5">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              placeholder="Profile suchen (Name, Username, E-Mail)…"
              className="pl-9"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="flex gap-2 shrink-0">
            <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(0); }}>
              <SelectTrigger className="w-36 h-9">
                <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Status</SelectItem>
                <SelectItem value="active">Aktiv</SelectItem>
                <SelectItem value="inactive">Inaktiv</SelectItem>
                <SelectItem value="banned">Gesperrt</SelectItem>
              </SelectContent>
            </Select>
            <Select value={platformFilter} onValueChange={(v) => { setPlatformFilter(v); setPage(0); }}>
              <SelectTrigger className="w-40 h-9">
                <SelectValue placeholder="Plattform" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle Plattformen</SelectItem>
                {PLATFORMS.map((p) => (
                  <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={() => setCreateOpen(true)} className="gap-2 shrink-0">
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Neues Profil</span>
            </Button>
          </div>
        </div>

        {/* Profile Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-48 bg-card border border-border rounded-xl animate-pulse" />
            ))}
          </div>
        ) : profiles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {profiles.map((profile) => (
              <Card
                key={profile.id}
                className="group hover:shadow-md transition-all duration-200 hover:border-primary/30"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-gradient-to-br from-primary/30 to-primary/10 text-primary font-semibold">
                            {profile.displayName[0].toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        {profile.isOnline && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-background" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{profile.displayName}</p>
                        <p className="text-xs text-muted-foreground truncate">@{profile.username}</p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link href={`/profiles/${profile.id}`}>
                            <Users className="w-4 h-4 mr-2" /> Details
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/chat/${profile.id}`}>
                            <MessageSquare className="w-4 h-4 mr-2" /> Chat öffnen
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href={`/automation?profileId=${profile.id}`}>
                            <Bot className="w-4 h-4 mr-2" /> Automatisierung
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setEditProfile(profile.id)}>
                          <Edit className="w-4 h-4 mr-2" /> Bearbeiten
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => setDeleteProfile({ id: profile.id, name: profile.displayName })}
                          className="text-destructive focus:text-destructive"
                        >
                          <Trash2 className="w-4 h-4 mr-2" /> Löschen
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  {profile.bio && (
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{profile.bio}</p>
                  )}

                  <div className="flex items-center justify-between">
                    <span
                      className={cn(
                        "text-xs px-2 py-0.5 rounded-full font-medium",
                        profile.status === "active" && "status-active",
                        profile.status === "inactive" && "status-inactive",
                        profile.status === "banned" && "status-banned"
                      )}
                    >
                      {STATUS_LABELS[profile.status]}
                    </span>
                    {profile.platform && profile.platform !== "general" && (
                      <Badge variant="outline" className="text-xs capitalize">
                        {profile.platform}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
                    <Link href={`/chat/${profile.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full h-7 text-xs gap-1">
                        <MessageSquare className="w-3 h-3" /> Chat
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0"
                      onClick={() => setEditProfile(profile.id)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 space-y-3">
            <Users className="w-12 h-12 text-muted-foreground/30 mx-auto" />
            <p className="text-muted-foreground">
              {search || statusFilter !== "all" || platformFilter !== "all"
                ? "Keine Profile gefunden. Passen Sie die Filter an."
                : "Noch keine Profile vorhanden. Erstellen Sie das erste Profil."}
            </p>
            {!search && statusFilter === "all" && platformFilter === "all" && (
              <Button onClick={() => setCreateOpen(true)} className="gap-2">
                <Plus className="w-4 h-4" /> Erstes Profil erstellen
              </Button>
            )}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between pt-2">
            <p className="text-sm text-muted-foreground">
              {page * 12 + 1}–{Math.min((page + 1) * 12, total)} von {total} Profilen
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                Zurück
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
              >
                Weiter
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <ProfileFormDialog
        open={createOpen || editProfile !== null}
        profileId={editProfile}
        onClose={() => { setCreateOpen(false); setEditProfile(null); }}
        onCreate={(data) => createMutation.mutate(data)}
        onUpdate={(id, data) => updateMutation.mutate({ id, ...data })}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteProfile} onOpenChange={() => setDeleteProfile(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Profil löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Das Profil <strong>{deleteProfile?.name}</strong> wird dauerhaft gelöscht. Diese Aktion
              kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteProfile && deleteMutation.mutate({ id: deleteProfile.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </NexusLayout>
  );
}

// ─── Profile Form Dialog ──────────────────────────────────────────────────────
function ProfileFormDialog({
  open,
  profileId,
  onClose,
  onCreate,
  onUpdate,
  isSubmitting,
}: {
  open: boolean;
  profileId: number | null;
  onClose: () => void;
  onCreate: (data: ProfileFormData) => void;
  onUpdate: (id: number, data: ProfileFormData) => void;
  isSubmitting: boolean;
}) {
  const { data: profile } = trpc.profiles.getById.useQuery(
    { id: profileId! },
    { enabled: !!profileId }
  );

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: "",
      username: "",
      email: "",
      phone: "",
      bio: "",
      platform: "general",
      status: "active",
    },
  });

  useEffect(() => {
    if (profile && profileId) {
      form.reset({
        displayName: profile.displayName,
        username: profile.username,
        email: profile.email ?? "",
        phone: profile.phone ?? "",
        bio: profile.bio ?? "",
        platform: profile.platform ?? "general",
        status: profile.status,
      });
    } else if (!profileId) {
      form.reset({
        displayName: "",
        username: "",
        email: "",
        phone: "",
        bio: "",
        platform: "general",
        status: "active",
      });
    }
  }, [profile, profileId]);

  const onSubmit = (data: ProfileFormData) => {
    if (profileId) {
      onUpdate(profileId, data);
    } else {
      onCreate(data);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{profileId ? "Profil bearbeiten" : "Neues Profil erstellen"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="displayName">Anzeigename *</Label>
              <Input id="displayName" {...form.register("displayName")} placeholder="Max Mustermann" />
              {form.formState.errors.displayName && (
                <p className="text-xs text-destructive">{form.formState.errors.displayName.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="username">Benutzername *</Label>
              <Input id="username" {...form.register("username")} placeholder="max_mustermann" />
              {form.formState.errors.username && (
                <p className="text-xs text-destructive">{form.formState.errors.username.message}</p>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">E-Mail</Label>
              <Input id="email" type="email" {...form.register("email")} placeholder="max@example.com" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="phone">Telefon</Label>
              <Input id="phone" {...form.register("phone")} placeholder="+49 123 456789" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Plattform</Label>
              <Select
                value={form.watch("platform") ?? "general"}
                onValueChange={(v) => form.setValue("platform", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PLATFORMS.map((p) => (
                    <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select
                value={form.watch("status") ?? "active"}
                onValueChange={(v) => form.setValue("status", v as "active" | "inactive" | "banned")}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="inactive">Inaktiv</SelectItem>
                  <SelectItem value="banned">Gesperrt</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="bio">Biografie</Label>
            <Textarea
              id="bio"
              {...form.register("bio")}
              placeholder="Kurze Beschreibung des Profils…"
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Wird gespeichert…" : profileId ? "Speichern" : "Erstellen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
