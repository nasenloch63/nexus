import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Bot,
  Calendar,
  Clock,
  Edit,
  MessageSquare,
  Plus,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Zap,
  AlertCircle,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useSearch } from "wouter";
import { z } from "zod";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const ruleSchema = z.object({
  profileId: z.number().min(1, "Profil erforderlich"),
  name: z.string().min(1, "Name erforderlich").max(128),
  description: z.string().optional(),
  triggerType: z.enum(["scheduled", "keyword", "inactivity", "welcome"]),
  triggerValue: z.string().optional(),
  messageContent: z.string().min(1, "Nachrichteninhalt erforderlich"),
  isActive: z.boolean().optional(),
});

type RuleFormData = z.infer<typeof ruleSchema>;

const TRIGGER_LABELS: Record<string, string> = {
  scheduled: "Geplant (Cron)",
  keyword: "Schlüsselwort",
  inactivity: "Inaktivität",
  welcome: "Willkommensnachricht",
};

const TRIGGER_ICONS: Record<string, React.ElementType> = {
  scheduled: Calendar,
  keyword: MessageSquare,
  inactivity: Clock,
  welcome: Zap,
};

export default function Automation() {
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const preselectedProfileId = params.get("profileId") ? parseInt(params.get("profileId")!) : null;

  const [selectedProfileId, setSelectedProfileId] = useState<number | null>(preselectedProfileId);
  const [createOpen, setCreateOpen] = useState(false);
  const [editRule, setEditRule] = useState<number | null>(null);
  const [deleteRule, setDeleteRule] = useState<{ id: number; name: string } | null>(null);

  const utils = trpc.useUtils();

  const { data: profilesData } = trpc.profiles.list.useQuery({ limit: 100 });
  const profiles = profilesData?.profiles ?? [];

  const { data: allRules, isLoading } = trpc.automation.all.useQuery();
  const { data: profileRules } = trpc.automation.byProfile.useQuery(
    { profileId: selectedProfileId! },
    { enabled: !!selectedProfileId }
  );

  const displayedRules = selectedProfileId ? (profileRules ?? []) : (allRules ?? []);

  const toggleMutation = trpc.automation.toggle.useMutation({
    onMutate: async ({ id, isActive }) => {
      await utils.automation.all.cancel();
      const prev = utils.automation.all.getData();
      utils.automation.all.setData(undefined, (old) =>
        old?.map((r) => (r.id === id ? { ...r, isActive } : r))
      );
      return { prev };
    },
    onError: (_, __, ctx) => {
      if (ctx?.prev) utils.automation.all.setData(undefined, ctx.prev);
      toast.error("Fehler beim Umschalten");
    },
    onSettled: () => {
      utils.automation.all.invalidate();
      utils.automation.byProfile.invalidate();
    },
  });

  const deleteMutation = trpc.automation.delete.useMutation({
    onSuccess: () => {
      utils.automation.all.invalidate();
      utils.automation.byProfile.invalidate();
      setDeleteRule(null);
      toast.success("Regel gelöscht");
    },
    onError: (e) => toast.error(e.message),
  });

  const createMutation = trpc.automation.create.useMutation({
    onSuccess: () => {
      utils.automation.all.invalidate();
      utils.automation.byProfile.invalidate();
      setCreateOpen(false);
      toast.success("Automatisierungsregel erstellt");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.automation.update.useMutation({
    onSuccess: () => {
      utils.automation.all.invalidate();
      utils.automation.byProfile.invalidate();
      setEditRule(null);
      toast.success("Regel aktualisiert");
    },
    onError: (e) => toast.error(e.message),
  });

  const activeRules = displayedRules.filter((r) => r.isActive).length;

  return (
    <NexusLayout
      title="Automatisierung"
      subtitle={`${displayedRules.length} Regeln konfiguriert, ${activeRules} aktiv`}
    >
      <div className="space-y-5">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <Select
            value={selectedProfileId?.toString() ?? "all"}
            onValueChange={(v) => setSelectedProfileId(v === "all" ? null : parseInt(v))}
          >
            <SelectTrigger className="w-56">
              <Users className="w-4 h-4 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Alle Profile" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle Profile</SelectItem>
              {profiles.map((p) => (
                <SelectItem key={p.id} value={p.id.toString()}>
                  {p.displayName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center gap-3 ml-auto">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-emerald-500 rounded-full" />
              <span>{activeRules} aktiv</span>
            </div>
            <Button onClick={() => setCreateOpen(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Neue Regel
            </Button>
          </div>
        </div>

        {/* Rules Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-40 bg-card border border-border rounded-xl animate-pulse" />
            ))}
          </div>
        ) : displayedRules.length === 0 ? (
          <div className="text-center py-16 space-y-3">
            <Bot className="w-12 h-12 text-muted-foreground/30 mx-auto" />
            <p className="text-muted-foreground">
              {selectedProfileId
                ? "Keine Regeln für dieses Profil konfiguriert."
                : "Noch keine Automatisierungsregeln vorhanden."}
            </p>
            <Button onClick={() => setCreateOpen(true)} className="gap-2">
              <Plus className="w-4 h-4" /> Erste Regel erstellen
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {displayedRules.map((rule) => {
              const TriggerIcon = TRIGGER_ICONS[rule.triggerType] ?? Bot;
              const profile = profiles.find((p) => p.id === rule.profileId);
              return (
                <Card
                  key={rule.id}
                  className={cn(
                    "transition-all duration-200",
                    rule.isActive
                      ? "border-primary/20 hover:border-primary/40"
                      : "opacity-70 hover:opacity-90"
                  )}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                            rule.isActive
                              ? "bg-primary/10 text-primary"
                              : "bg-muted text-muted-foreground"
                          )}
                        >
                          <TriggerIcon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-sm truncate">{rule.name}</p>
                          {profile && (
                            <p className="text-xs text-muted-foreground truncate">
                              @{profile.username}
                            </p>
                          )}
                        </div>
                      </div>
                      {/* Toggle Switch */}
                      <Switch
                        checked={rule.isActive}
                        onCheckedChange={(checked) =>
                          toggleMutation.mutate({ id: rule.id, isActive: checked })
                        }
                        className="shrink-0"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs capitalize">
                          {TRIGGER_LABELS[rule.triggerType]}
                        </Badge>
                        {rule.triggerValue && (
                          <span className="text-xs text-muted-foreground font-mono truncate">
                            {rule.triggerValue}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-muted-foreground line-clamp-2 bg-muted/50 rounded-lg px-2 py-1.5">
                        {rule.messageContent}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                      <div className="text-xs text-muted-foreground">
                        {rule.triggerCount > 0 ? (
                          <span>{rule.triggerCount}x ausgelöst</span>
                        ) : (
                          <span>Noch nicht ausgelöst</span>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => setEditRule(rule.id)}
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => setDeleteRule({ id: rule.id, name: rule.name })}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Create/Edit Dialog */}
      <RuleFormDialog
        open={createOpen || editRule !== null}
        ruleId={editRule}
        profiles={profiles}
        preselectedProfileId={selectedProfileId}
        onClose={() => { setCreateOpen(false); setEditRule(null); }}
        onCreate={(data) => createMutation.mutate(data)}
        onUpdate={(id, data) => updateMutation.mutate({ id, ...data })}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteRule} onOpenChange={() => setDeleteRule(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Regel löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Die Regel <strong>{deleteRule?.name}</strong> wird dauerhaft gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteRule && deleteMutation.mutate({ id: deleteRule.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </NexusLayout>
  );
}

// ─── Rule Form Dialog ─────────────────────────────────────────────────────────
function RuleFormDialog({
  open,
  ruleId,
  profiles,
  preselectedProfileId,
  onClose,
  onCreate,
  onUpdate,
  isSubmitting,
}: {
  open: boolean;
  ruleId: number | null;
  profiles: Array<{ id: number; displayName: string; username: string }>;
  preselectedProfileId: number | null;
  onClose: () => void;
  onCreate: (data: RuleFormData) => void;
  onUpdate: (id: number, data: Partial<RuleFormData>) => void;
  isSubmitting: boolean;
}) {
  const { data: rule } = trpc.automation.byProfile.useQuery(
    { profileId: 0 },
    { enabled: false }
  );

  const form = useForm<RuleFormData>({
    resolver: zodResolver(ruleSchema),
    defaultValues: {
      profileId: preselectedProfileId ?? undefined,
      name: "",
      description: "",
      triggerType: "scheduled",
      triggerValue: "",
      messageContent: "",
      isActive: true,
    },
  });

  useEffect(() => {
    if (!ruleId) {
      form.reset({
        profileId: preselectedProfileId ?? undefined,
        name: "",
        description: "",
        triggerType: "scheduled",
        triggerValue: "",
        messageContent: "",
        isActive: true,
      });
    }
  }, [ruleId, preselectedProfileId, open]);

  const triggerType = form.watch("triggerType");

  const triggerPlaceholders: Record<string, string> = {
    scheduled: "0 9 * * 1-5 (Cron-Ausdruck)",
    keyword: "hallo, hilfe, support",
    inactivity: "60 (Minuten)",
    welcome: "Leer lassen",
  };

  const onSubmit = (data: RuleFormData) => {
    if (ruleId) {
      onUpdate(ruleId, data);
    } else {
      onCreate(data);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{ruleId ? "Regel bearbeiten" : "Neue Automatisierungsregel"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Profil *</Label>
            <Select
              value={form.watch("profileId")?.toString() ?? ""}
              onValueChange={(v) => form.setValue("profileId", parseInt(v))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Profil auswählen…" />
              </SelectTrigger>
              <SelectContent>
                {profiles.map((p) => (
                  <SelectItem key={p.id} value={p.id.toString()}>
                    {p.displayName} (@{p.username})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.profileId && (
              <p className="text-xs text-destructive">{form.formState.errors.profileId.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="name">Regelname *</Label>
              <Input id="name" {...form.register("name")} placeholder="Tägliche Begrüßung" />
              {form.formState.errors.name && (
                <p className="text-xs text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Auslöser-Typ *</Label>
              <Select
                value={triggerType}
                onValueChange={(v) => form.setValue("triggerType", v as RuleFormData["triggerType"])}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(TRIGGER_LABELS).map(([value, label]) => (
                    <SelectItem key={value} value={value}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {triggerType !== "welcome" && (
            <div className="space-y-1.5">
              <Label htmlFor="triggerValue">Auslöser-Wert</Label>
              <Input
                id="triggerValue"
                {...form.register("triggerValue")}
                placeholder={triggerPlaceholders[triggerType]}
              />
              <p className="text-xs text-muted-foreground">
                {triggerType === "scheduled" && "Cron-Ausdruck: Sekunden Minuten Stunden Tag Monat Wochentag"}
                {triggerType === "keyword" && "Kommagetrennte Schlüsselwörter"}
                {triggerType === "inactivity" && "Inaktivitätsdauer in Minuten"}
              </p>
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="messageContent">Nachrichteninhalt *</Label>
            <Textarea
              id="messageContent"
              {...form.register("messageContent")}
              placeholder="Hallo! Wie kann ich Ihnen helfen?"
              rows={3}
            />
            {form.formState.errors.messageContent && (
              <p className="text-xs text-destructive">{form.formState.errors.messageContent.message}</p>
            )}
          </div>

          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <Switch
              checked={form.watch("isActive") ?? true}
              onCheckedChange={(v) => form.setValue("isActive", v)}
            />
            <div>
              <p className="text-sm font-medium">Regel sofort aktivieren</p>
              <p className="text-xs text-muted-foreground">Die Regel wird nach dem Erstellen aktiv</p>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Abbrechen</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Wird gespeichert…" : ruleId ? "Speichern" : "Erstellen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
