import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { useMemo } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Activity, Bot, MessageSquare, TrendingUp, Users, Zap } from "lucide-react";

export default function Analytics() {
  const { data: overview, isLoading } = trpc.analytics.overview.useQuery();
  const { data: volume7 } = trpc.analytics.messageVolume.useQuery({ days: 7 });
  const { data: volume30 } = trpc.analytics.messageVolume.useQuery({ days: 30 });
  const { data: statusData } = trpc.analytics.profilesByStatus.useQuery();

  const chart7 = useMemo(
    () =>
      (volume7 ?? []).map((d) => ({
        date: new Date(d.date).toLocaleDateString("de-DE", { weekday: "short", day: "numeric" }),
        Nachrichten: d.count,
      })),
    [volume7]
  );

  const chart30 = useMemo(
    () =>
      (volume30 ?? []).map((d) => ({
        date: new Date(d.date).toLocaleDateString("de-DE", { day: "numeric", month: "short" }),
        Nachrichten: d.count,
      })),
    [volume30]
  );

  const pieData = useMemo(() => {
    const colors: Record<string, string> = {
      active: "#22c55e",
      inactive: "#f59e0b",
      banned: "#ef4444",
    };
    const labels: Record<string, string> = {
      active: "Aktiv",
      inactive: "Inaktiv",
      banned: "Gesperrt",
    };
    return (statusData ?? []).map((d) => ({
      name: labels[d.status] ?? d.status,
      value: d.count,
      color: colors[d.status] ?? "#6b7280",
    }));
  }, [statusData]);

  const tooltipStyle = {
    backgroundColor: "var(--color-popover)",
    border: "1px solid var(--color-border)",
    borderRadius: "8px",
    fontSize: "12px",
    color: "var(--color-foreground)",
  };

  const kpis = [
    {
      label: "Gesamt-Profile",
      value: overview?.totalProfiles ?? 0,
      icon: Users,
      color: "text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/30",
    },
    {
      label: "Aktive Profile",
      value: overview?.activeProfiles ?? 0,
      icon: Activity,
      color: "text-emerald-600 bg-emerald-100 dark:text-emerald-400 dark:bg-emerald-900/30",
    },
    {
      label: "Online jetzt",
      value: overview?.onlineProfiles ?? 0,
      icon: Zap,
      color: "text-violet-600 bg-violet-100 dark:text-violet-400 dark:bg-violet-900/30",
    },
    {
      label: "Gesamt-Nachrichten",
      value: overview?.totalMessages ?? 0,
      icon: MessageSquare,
      color: "text-orange-600 bg-orange-100 dark:text-orange-400 dark:bg-orange-900/30",
    },
    {
      label: "Nachrichten heute",
      value: overview?.todayMessages ?? 0,
      icon: TrendingUp,
      color: "text-pink-600 bg-pink-100 dark:text-pink-400 dark:bg-pink-900/30",
    },
    {
      label: "Aktive Automationen",
      value: overview?.activeRules ?? 0,
      icon: Bot,
      color: "text-cyan-600 bg-cyan-100 dark:text-cyan-400 dark:bg-cyan-900/30",
    },
  ];

  return (
    <NexusLayout title="Analytics" subtitle="Detaillierte Metriken und Auswertungen">
      <div className="space-y-6">
        {/* KPI Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {kpis.map((kpi) => (
            <Card key={kpi.label}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${kpi.color}`}>
                    <kpi.icon className="w-4 h-4" />
                  </div>
                </div>
                {isLoading ? (
                  <Skeleton className="h-7 w-16 mb-1" />
                ) : (
                  <p className="text-2xl font-bold">{kpi.value.toLocaleString("de-DE")}</p>
                )}
                <p className="text-xs text-muted-foreground">{kpi.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 7-Day Volume */}
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold">Nachrichtenvolumen (7 Tage)</CardTitle>
                <Badge variant="secondary" className="text-xs">Täglich</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {chart7.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={chart7} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="grad7" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.62 0.22 264)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="oklch(0.62 0.22 264)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Area
                      type="monotone"
                      dataKey="Nachrichten"
                      stroke="oklch(0.62 0.22 264)"
                      strokeWidth={2}
                      fill="url(#grad7)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                  Noch keine Daten für die letzten 7 Tage
                </div>
              )}
            </CardContent>
          </Card>

          {/* Profile Status */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">Profil-Verteilung</CardTitle>
            </CardHeader>
            <CardContent>
              {pieData.length > 0 ? (
                <div className="space-y-3">
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={tooltipStyle} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2">
                    {pieData.map((d) => (
                      <div key={d.name} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                          <span className="text-muted-foreground">{d.name}</span>
                        </div>
                        <span className="font-semibold">{d.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="h-52 flex items-center justify-center text-muted-foreground text-sm">
                  Keine Profile vorhanden
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 30-Day Bar Chart */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold">Nachrichtenvolumen (30 Tage)</CardTitle>
              <Badge variant="secondary" className="text-xs">Monatlich</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {chart30.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chart30} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={2} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Bar dataKey="Nachrichten" fill="oklch(0.62 0.22 264)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                Noch keine Daten für die letzten 30 Tage
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </NexusLayout>
  );
}
