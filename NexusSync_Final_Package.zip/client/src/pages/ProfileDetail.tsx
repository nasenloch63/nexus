import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { ArrowLeft, Bot, Edit, Mail, MessageSquare, Phone, Tag } from "lucide-react";
import { Link, useParams } from "wouter";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function ProfileDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");

  const { data: profile, isLoading } = trpc.profiles.getById.useQuery({ id }, { enabled: !!id });
  const { data: messages } = trpc.messages.byProfile.useQuery({ profileId: id, limit: 5 }, { enabled: !!id });
  const { data: rules } = trpc.automation.byProfile.useQuery({ profileId: id }, { enabled: !!id });

  if (isLoading) {
    return (
      <NexusLayout title="Profil laden…">
        <div className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </NexusLayout>
    );
  }

  if (!profile) {
    return (
      <NexusLayout title="Profil nicht gefunden">
        <div className="text-center py-16">
          <p className="text-muted-foreground">Dieses Profil existiert nicht.</p>
          <Link href="/profiles">
            <Button variant="outline" className="mt-4 gap-2">
              <ArrowLeft className="w-4 h-4" /> Zurück zu Profilen
            </Button>
          </Link>
        </div>
      </NexusLayout>
    );
  }

  const statusLabels: Record<string, string> = {
    active: "Aktiv", inactive: "Inaktiv", banned: "Gesperrt",
  };

  return (
    <NexusLayout title={profile.displayName} subtitle={`@${profile.username}`}>
      <div className="space-y-5">
        {/* Back + Actions */}
        <div className="flex items-center justify-between">
          <Link href="/profiles">
            <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
              <ArrowLeft className="w-4 h-4" /> Alle Profile
            </Button>
          </Link>
          <div className="flex gap-2">
            <Link href={`/chat/${profile.id}`}>
              <Button variant="outline" size="sm" className="gap-2">
                <MessageSquare className="w-4 h-4" /> Chat öffnen
              </Button>
            </Link>
            <Link href={`/automation?profileId=${profile.id}`}>
              <Button variant="outline" size="sm" className="gap-2">
                <Bot className="w-4 h-4" /> Automatisierung
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Profile Card */}
          <Card className="lg:col-span-1">
            <CardContent className="p-6 text-center">
              <div className="relative inline-block mb-4">
                <Avatar className="w-20 h-20">
                  <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-primary/30 to-primary/10 text-primary">
                    {profile.displayName[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {profile.isOnline && (
                  <div className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-background" />
                )}
              </div>
              <h2 className="text-xl font-bold">{profile.displayName}</h2>
              <p className="text-muted-foreground text-sm">@{profile.username}</p>
              {profile.bio && (
                <p className="text-sm text-muted-foreground mt-3 text-center">{profile.bio}</p>
              )}
              <div className="flex items-center justify-center gap-2 mt-4">
                <span
                  className={cn(
                    "text-xs px-3 py-1 rounded-full font-medium",
                    profile.status === "active" && "status-active",
                    profile.status === "inactive" && "status-inactive",
                    profile.status === "banned" && "status-banned"
                  )}
                >
                  {statusLabels[profile.status]}
                </span>
                {profile.platform && profile.platform !== "general" && (
                  <Badge variant="outline" className="text-xs capitalize">{profile.platform}</Badge>
                )}
              </div>
              <div className="mt-4 pt-4 border-t border-border space-y-2 text-left">
                {profile.email && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4 shrink-0" />
                    <span className="truncate">{profile.email}</span>
                  </div>
                )}
                {profile.phone && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4 shrink-0" />
                    <span>{profile.phone}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MessageSquare className="w-4 h-4 shrink-0" />
                  <span>{profile.totalMessages} Nachrichten gesamt</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Right Column */}
          <div className="lg:col-span-2 space-y-5">
            {/* Recent Messages */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold">Letzte Nachrichten</CardTitle>
                  <Link href={`/chat/${profile.id}`}>
                    <Button variant="ghost" size="sm" className="text-xs h-7">Chat öffnen</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {messages && messages.length > 0 ? (
                  <div className="space-y-2">
                    {messages.map((msg) => (
                      <div key={msg.id} className="flex items-start gap-3 p-2 rounded-lg bg-muted/30">
                        <div className={cn(
                          "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5",
                          msg.senderType === "admin" ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                        )}>
                          {msg.senderType === "admin" ? "A" : "U"}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm">{msg.content}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {new Date(msg.createdAt).toLocaleString("de-DE")}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">Noch keine Nachrichten</p>
                )}
              </CardContent>
            </Card>

            {/* Automation Rules */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-semibold">Automatisierungsregeln</CardTitle>
                  <Link href={`/automation?profileId=${profile.id}`}>
                    <Button variant="ghost" size="sm" className="text-xs h-7">Verwalten</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {rules && rules.length > 0 ? (
                  <div className="space-y-2">
                    {rules.slice(0, 3).map((rule) => (
                      <div key={rule.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{rule.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{rule.triggerType}</p>
                        </div>
                        <Badge variant={rule.isActive ? "default" : "secondary"} className="text-xs shrink-0">
                          {rule.isActive ? "Aktiv" : "Inaktiv"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">Keine Regeln konfiguriert</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </NexusLayout>
  );
}
