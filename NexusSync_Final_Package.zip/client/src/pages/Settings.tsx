import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { zodResolver } from "@hookform/resolvers/zod";
import { Edit, Plus, Trash2, Zap, MessageSquare, Settings } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const quickReplySchema = z.object({
  title: z.string().min(1, "Titel erforderlich").max(64),
  content: z.string().min(1, "Inhalt erforderlich"),
  category: z.string().optional(),
});

type QuickReplyFormData = z.infer<typeof quickReplySchema>;

export default function SettingsPage() {
  const [createOpen, setCreateOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [deleteItem, setDeleteItem] = useState<{ id: number; title: string } | null>(null);

  const utils = trpc.useUtils();
  const { data: quickReplies, isLoading } = trpc.quickReplies.list.useQuery();

  const createMutation = trpc.quickReplies.create.useMutation({
    onSuccess: () => {
      utils.quickReplies.list.invalidate();
      setCreateOpen(false);
      toast.success("Schnellantwort erstellt");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateMutation = trpc.quickReplies.update.useMutation({
    onSuccess: () => {
      utils.quickReplies.list.invalidate();
      setEditId(null);
      toast.success("Schnellantwort aktualisiert");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = trpc.quickReplies.delete.useMutation({
    onSuccess: () => {
      utils.quickReplies.list.invalidate();
      setDeleteItem(null);
      toast.success("Schnellantwort gelöscht");
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <NexusLayout title="Einstellungen" subtitle="Systemkonfiguration und Vorlagen verwalten">
      <Tabs defaultValue="quick-replies">
        <TabsList className="mb-6">
          <TabsTrigger value="quick-replies" className="gap-2">
            <Zap className="w-4 h-4" /> Schnellantworten
          </TabsTrigger>
          <TabsTrigger value="system" className="gap-2">
            <Settings className="w-4 h-4" /> System
          </TabsTrigger>
        </TabsList>

        {/* Quick Replies Tab */}
        <TabsContent value="quick-replies" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Schnellantwort-Templates</h3>
              <p className="text-sm text-muted-foreground mt-0.5">
                Vordefinierte Antworten für häufige Anfragen im Chat-Interface
              </p>
            </div>
            <Button onClick={() => setCreateOpen(true)} className="gap-2">
              <Plus className="w-4 h-4" /> Neue Vorlage
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-28 bg-card border border-border rounded-xl animate-pulse" />
              ))}
            </div>
          ) : quickReplies && quickReplies.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {quickReplies.map((qr) => (
                <Card key={qr.id} className="group hover:border-primary/30 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm truncate">{qr.title}</p>

                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => setEditId(qr.id)}
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => setDeleteItem({ id: qr.id, title: qr.title })}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-3">{qr.content}</p>
                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-border">
                      {qr.category && (
                        <Badge variant="secondary" className="text-xs">{qr.category}</Badge>
                      )}
                      <span className="text-xs text-muted-foreground ml-auto">
                        {qr.usageCount}x verwendet
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 space-y-3">
              <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto" />
              <p className="text-muted-foreground">Noch keine Schnellantworten konfiguriert.</p>
              <Button onClick={() => setCreateOpen(true)} className="gap-2">
                <Plus className="w-4 h-4" /> Erste Vorlage erstellen
              </Button>
            </div>
          )}
        </TabsContent>

        {/* System Tab */}
        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Systemstatus</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: "Datenbankverbindung", status: "Verbunden", ok: true },
                { label: "Socket.io-Server", status: "Aktiv", ok: true },
                { label: "Automatisierungs-Engine", status: "Bereit", ok: true },
                { label: "API-Endpunkte", status: "Erreichbar", ok: true },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <span className="text-sm">{item.label}</span>
                  <Badge
                    variant="secondary"
                    className={item.ok ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" : "bg-red-100 text-red-700"}
                  >
                    {item.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Über NexusSync</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p>NexusSync — Fortgeschrittenes Admin-Dashboard für Multi-Profil-Verwaltung</p>
              <p>Version 1.0.0</p>
              <p>Technologie-Stack: React 19, tRPC, Drizzle ORM, Socket.io, Tailwind CSS 4</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create/Edit Dialog */}
      <QuickReplyFormDialog
        open={createOpen || editId !== null}
        itemId={editId}
        onClose={() => { setCreateOpen(false); setEditId(null); }}
        onCreate={(data) => createMutation.mutate(data)}
        onUpdate={(id, data) => updateMutation.mutate({ id, ...data })}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
        existingItems={quickReplies ?? []}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Schnellantwort löschen?</AlertDialogTitle>
            <AlertDialogDescription>
              Die Vorlage <strong>{deleteItem?.title}</strong> wird dauerhaft gelöscht.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteItem && deleteMutation.mutate({ id: deleteItem.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </NexusLayout>
  );
}

function QuickReplyFormDialog({
  open,
  itemId,
  onClose,
  onCreate,
  onUpdate,
  isSubmitting,
  existingItems,
}: {
  open: boolean;
  itemId: number | null;
  onClose: () => void;
  onCreate: (data: QuickReplyFormData) => void;
  onUpdate: (id: number, data: QuickReplyFormData) => void;
  isSubmitting: boolean;
  existingItems: Array<{ id: number; title: string; content: string; category?: string | null }>;
}) {
  const existing = itemId ? existingItems.find((i) => i.id === itemId) : null;

  const form = useForm<QuickReplyFormData>({
    resolver: zodResolver(quickReplySchema),
    defaultValues: existing
      ? {
          title: existing.title,
          content: existing.content,
          category: existing.category ?? "",
        }
      : { title: "", content: "", category: "" },
  });

  const onSubmit = (data: QuickReplyFormData) => {
    if (itemId) {
      onUpdate(itemId, data);
    } else {
      onCreate(data);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {itemId ? "Schnellantwort bearbeiten" : "Neue Schnellantwort"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="qr-title">Titel *</Label>
              <Input id="qr-title" {...form.register("title")} placeholder="Begrüßung" />
              {form.formState.errors.title && (
                <p className="text-xs text-destructive">{form.formState.errors.title.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="qr-category">Kategorie</Label>
              <Input id="qr-category-2" {...form.register("category")} placeholder="Support, Vertrieb…" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="qr-content">Nachrichteninhalt *</Label>
            <Textarea
              id="qr-content"
              {...form.register("content")}
              placeholder="Hallo! Willkommen bei NexusSync. Wie kann ich Ihnen helfen?"
              rows={4}
            />
            {form.formState.errors.content && (
              <p className="text-xs text-destructive">{form.formState.errors.content.message}</p>
            )}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Abbrechen</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Wird gespeichert…" : itemId ? "Speichern" : "Erstellen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
