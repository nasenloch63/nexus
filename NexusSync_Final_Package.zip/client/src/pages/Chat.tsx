import NexusLayout from "@/components/NexusLayout";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  ChevronLeft,
  MessageSquare,
  Paperclip,
  Send,
  Users,
  X,
  Zap,
  Bot,
} from "lucide-react";
import { useEffect, useRef, useState, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { io, Socket } from "socket.io-client";
import { toast } from "sonner";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Link } from "wouter";

interface LiveMessage {
  id?: number;
  profileId: number;
  content: string;
  senderType: "admin" | "user" | "system" | "automated";
  createdAt: string;
  isOptimistic?: boolean;
}

let socketInstance: Socket | null = null;

function getSocket(): Socket {
  if (!socketInstance) {
    socketInstance = io(window.location.origin, {
      path: "/api/socket.io",
      transports: ["websocket", "polling"],
    });
  }
  return socketInstance;
}

export default function Chat() {
  const params = useParams<{ profileId: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const activeProfileId = params.profileId ? parseInt(params.profileId) : null;

  const [liveMessages, setLiveMessages] = useState<LiveMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [quickReplyOpen, setQuickReplyOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const utils = trpc.useUtils();

  // Fetch profiles list for sidebar
  const { data: profilesData } = trpc.profiles.list.useQuery({ limit: 50 });
  const profiles = profilesData?.profiles ?? [];

  // Fetch active profile details
  const { data: activeProfile } = trpc.profiles.getById.useQuery(
    { id: activeProfileId! },
    { enabled: !!activeProfileId }
  );

  // Fetch message history
  const { data: messageHistory, isLoading: historyLoading } = trpc.messages.byProfile.useQuery(
    { profileId: activeProfileId!, limit: 50 },
    { enabled: !!activeProfileId }
  );

  // Quick reply templates
  const { data: quickReplies } = trpc.quickReplies.list.useQuery();
  const useQuickReply = trpc.quickReplies.use.useMutation();

  // Send message mutation (fallback for non-socket)
  const sendMutation = trpc.messages.send.useMutation({
    onSuccess: () => utils.messages.byProfile.invalidate({ profileId: activeProfileId! }),
  });

  // Socket.io setup
  useEffect(() => {
    const socket = getSocket();

    socket.on("connect", () => setIsConnected(true));
    socket.on("disconnect", () => setIsConnected(false));

    socket.on("message:new", (msg: LiveMessage) => {
      if (msg.profileId === activeProfileId) {
        setLiveMessages((prev) => {
          // Remove optimistic message if exists
          const filtered = prev.filter((m) => !m.isOptimistic || m.content !== msg.content);
          return [...filtered, msg];
        });
      }
    });

    socket.on("typing:start", () => setIsTyping(true));
    socket.on("typing:stop", () => setIsTyping(false));

    return () => {
      socket.off("message:new");
      socket.off("typing:start");
      socket.off("typing:stop");
      socket.off("connect");
      socket.off("disconnect");
    };
  }, [activeProfileId]);

  // Join/leave profile room
  useEffect(() => {
    if (!activeProfileId) return;
    const socket = getSocket();
    socket.emit("join:profile", activeProfileId);
    setLiveMessages([]);
    return () => {
      socket.emit("leave:profile", activeProfileId);
    };
  }, [activeProfileId]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [liveMessages, messageHistory]);

  const allMessages = [
    ...(messageHistory ?? []).map((m) => ({
      ...m,
      createdAt: m.createdAt.toISOString(),
    })),
    ...liveMessages,
  ].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const sendMessage = useCallback(() => {
    if (!inputValue.trim() || !activeProfileId) return;

    const content = inputValue.trim();
    setInputValue("");

    // Optimistic update
    const optimistic: LiveMessage = {
      profileId: activeProfileId,
      content,
      senderType: "admin",
      createdAt: new Date().toISOString(),
      isOptimistic: true,
    };
    setLiveMessages((prev) => [...prev, optimistic]);

    // Send via socket
    const socket = getSocket();
    if (socket.connected) {
      socket.emit("message:send", {
        profileId: activeProfileId,
        content,
        senderId: user?.id,
        senderType: "admin",
      });
    } else {
      // Fallback to tRPC
      sendMutation.mutate({ profileId: activeProfileId, content });
    }
  }, [inputValue, activeProfileId, user]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleTyping = () => {
    if (!activeProfileId) return;
    const socket = getSocket();
    socket.emit("typing:start", activeProfileId);
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit("typing:stop", activeProfileId);
    }, 1500);
  };

  const applyQuickReply = (content: string, id: number) => {
    setInputValue(content);
    setQuickReplyOpen(false);
    useQuickReply.mutate({ id });
  };

  return (
    <NexusLayout title="Chat" subtitle="Echtzeit-Kommunikation mit allen Profilen">
      <div className="flex h-[calc(100vh-8rem)] gap-4">
        {/* ── Profile List Sidebar ──────────────────────────────────── */}
        <div
          className={cn(
            "w-72 shrink-0 bg-card border border-border rounded-xl overflow-hidden flex flex-col",
            activeProfileId ? "hidden lg:flex" : "flex"
          )}
        >
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-sm">Aktive Profile</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{profiles.length} Profile</p>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {profiles.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  Keine Profile vorhanden
                </div>
              ) : (
                profiles.map((profile) => (
                  <Link key={profile.id} href={`/chat/${profile.id}`}>
                    <div
                      className={cn(
                        "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors",
                        activeProfileId === profile.id
                          ? "bg-primary/10 border border-primary/20"
                          : "hover:bg-muted/50"
                      )}
                    >
                      <div className="relative shrink-0">
                        <Avatar className="w-9 h-9">
                          <AvatarFallback className="text-xs bg-primary/20 text-primary font-semibold">
                            {profile.displayName[0].toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        {profile.isOnline && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-background" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{profile.displayName}</p>
                        <p className="text-xs text-muted-foreground truncate">@{profile.username}</p>
                      </div>
                      <div className="shrink-0">
                        <span
                          className={cn(
                            "w-2 h-2 rounded-full block",
                            profile.status === "active" ? "bg-emerald-500" : "bg-muted-foreground/30"
                          )}
                        />
                      </div>
                    </div>
                  </Link>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        {/* ── Chat Area ─────────────────────────────────────────────── */}
        <div className="flex-1 flex flex-col bg-card border border-border rounded-xl overflow-hidden min-w-0">
          {activeProfileId && activeProfile ? (
            <>
              {/* Chat Header */}
              <div className="flex items-center gap-3 p-4 border-b border-border shrink-0">
                <Link href="/chat">
                  <Button variant="ghost" size="icon" className="h-8 w-8 lg:hidden">
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                </Link>
                <div className="relative">
                  <Avatar className="w-9 h-9">
                    <AvatarFallback className="bg-primary/20 text-primary font-semibold text-sm">
                      {activeProfile.displayName[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  {activeProfile.isOnline && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-background" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-sm">{activeProfile.displayName}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">@{activeProfile.username}</span>
                    {isConnected ? (
                      <Badge variant="secondary" className="text-xs py-0 px-1.5 h-4 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
                        Live
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="text-xs py-0 px-1.5 h-4">
                        Offline
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <Link href={`/automation?profileId=${activeProfileId}`}>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Bot className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                {historyLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className={cn("flex", i % 2 === 0 ? "justify-end" : "justify-start")}>
                        <Skeleton className="h-10 w-48 rounded-2xl" />
                      </div>
                    ))}
                  </div>
                ) : allMessages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center py-12 space-y-3">
                    <MessageSquare className="w-12 h-12 text-muted-foreground/30" />
                    <p className="text-muted-foreground text-sm">Noch keine Nachrichten</p>
                    <p className="text-xs text-muted-foreground">Beginnen Sie die Konversation unten</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {allMessages.map((msg, idx) => {
                      const isAdmin = msg.senderType === "admin";
                      const isAutomated = msg.senderType === "automated";
                      return (
                        <div
                          key={idx}
                          className={cn(
                            "flex",
                            isAdmin || isAutomated ? "justify-end" : "justify-start"
                          )}
                        >
                          <div
                            className={cn(
                              "max-w-[75%] rounded-2xl px-4 py-2.5 text-sm",
                              isAdmin
                                ? "bg-primary text-primary-foreground rounded-br-sm"
                                : isAutomated
                                ? "bg-violet-100 text-violet-900 dark:bg-violet-900/30 dark:text-violet-100 rounded-br-sm"
                                : "bg-muted text-foreground rounded-bl-sm",
                              (msg as LiveMessage).isOptimistic && "opacity-70"
                            )}
                          >
                            {isAutomated && (
                              <div className="flex items-center gap-1 mb-1 text-xs opacity-70">
                                <Bot className="w-3 h-3" /> Automatisiert
                              </div>
                            )}
                            <p className="leading-relaxed">{msg.content}</p>
                            <p
                              className={cn(
                                "text-xs mt-1 opacity-60",
                                isAdmin || isAutomated ? "text-right" : "text-left"
                              )}
                            >
                              {new Date(msg.createdAt).toLocaleTimeString("de-DE", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                    {isTyping && (
                      <div className="flex justify-start">
                        <div className="bg-muted rounded-2xl rounded-bl-sm px-4 py-2.5">
                          <div className="flex gap-1">
                            {[0, 1, 2].map((i) => (
                              <div
                                key={i}
                                className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"
                                style={{ animationDelay: `${i * 0.15}s` }}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>

              {/* Input Area */}
              <div className="p-4 border-t border-border shrink-0">
                {/* Quick Reply Templates */}
                {quickReplies && quickReplies.length > 0 && (
                  <div className="flex gap-2 mb-3 overflow-x-auto pb-1">
                    {quickReplies.slice(0, 4).map((qr) => (
                      <button
                        key={qr.id}
                        onClick={() => applyQuickReply(qr.content, qr.id)}
                        className="shrink-0 text-xs px-3 py-1.5 bg-accent hover:bg-accent/80 text-accent-foreground rounded-full transition-colors"
                      >
                        {qr.title}
                      </button>
                    ))}
                    {quickReplies.length > 4 && (
                      <Popover open={quickReplyOpen} onOpenChange={setQuickReplyOpen}>
                        <PopoverTrigger asChild>
                          <button className="shrink-0 text-xs px-3 py-1.5 bg-muted hover:bg-muted/80 text-muted-foreground rounded-full transition-colors">
                            +{quickReplies.length - 4} mehr
                          </button>
                        </PopoverTrigger>
                        <PopoverContent className="w-72 p-2" align="start">
                          <div className="space-y-1">
                            {quickReplies.slice(4).map((qr) => (
                              <button
                                key={qr.id}
                                onClick={() => applyQuickReply(qr.content, qr.id)}
                                className="w-full text-left px-3 py-2 rounded-lg hover:bg-muted text-sm transition-colors"
                              >
                                <p className="font-medium text-xs">{qr.title}</p>
                                <p className="text-muted-foreground text-xs truncate">{qr.content}</p>
                              </button>
                            ))}
                          </div>
                        </PopoverContent>
                      </Popover>
                    )}
                  </div>
                )}
                <div className="flex gap-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => {
                      setInputValue(e.target.value);
                      handleTyping();
                    }}
                    onKeyDown={handleKeyDown}
                    placeholder="Nachricht eingeben… (Enter zum Senden)"
                    className="flex-1"
                  />
                  <Button
                    onClick={sendMessage}
                    disabled={!inputValue.trim()}
                    size="icon"
                    className="shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 text-center">
                  {isConnected ? (
                    <span className="text-emerald-600 dark:text-emerald-400">
                      Echtzeit-Verbindung aktiv
                    </span>
                  ) : (
                    <span className="text-amber-600 dark:text-amber-400">
                      Verbindung wird hergestellt…
                    </span>
                  )}
                </p>
              </div>
            </>
          ) : (
            /* No profile selected */
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                <MessageSquare className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Chat-Interface</h3>
                <p className="text-muted-foreground text-sm mt-1">
                  Wählen Sie ein Profil aus der linken Liste, um den Chat zu öffnen.
                </p>
              </div>
              {profiles.length === 0 && (
                <Link href="/profiles">
                  <Button variant="outline" className="gap-2">
                    <Users className="w-4 h-4" /> Profile erstellen
                  </Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </div>
    </NexusLayout>
  );
}
