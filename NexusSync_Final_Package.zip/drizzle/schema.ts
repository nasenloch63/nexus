import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

// ─── Users (Auth) ────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── User Profiles (managed accounts) ────────────────────────────────────────
export const userProfiles = mysqlTable("user_profiles", {
  id: int("id").autoincrement().primaryKey(),
  createdBy: int("createdBy").notNull(), // FK → users.id
  displayName: varchar("displayName", { length: 128 }).notNull(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  avatarUrl: text("avatarUrl"),
  bio: text("bio"),
  status: mysqlEnum("status", ["active", "inactive", "banned"]).default("active").notNull(),
  platform: varchar("platform", { length: 64 }).default("general"),
  tags: text("tags"), // JSON array stored as text
  isOnline: boolean("isOnline").default(false).notNull(),
  lastSeen: timestamp("lastSeen").defaultNow(),
  totalMessages: int("totalMessages").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

// ─── Messages ─────────────────────────────────────────────────────────────────
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(), // FK → userProfiles.id
  senderId: int("senderId"), // FK → users.id (null = automated/system)
  senderType: mysqlEnum("senderType", ["admin", "user", "system", "automated"]).default("admin").notNull(),
  content: text("content").notNull(),
  messageType: mysqlEnum("messageType", ["text", "image", "file", "template"]).default("text").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  metadata: text("metadata"), // JSON for extra data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ─── Quick Reply Templates ────────────────────────────────────────────────────
export const quickReplyTemplates = mysqlTable("quick_reply_templates", {
  id: int("id").autoincrement().primaryKey(),
  createdBy: int("createdBy").notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  content: text("content").notNull(),
  category: varchar("category", { length: 64 }).default("general"),
  usageCount: int("usageCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type QuickReplyTemplate = typeof quickReplyTemplates.$inferSelect;
export type InsertQuickReplyTemplate = typeof quickReplyTemplates.$inferInsert;

// ─── Automation Rules ─────────────────────────────────────────────────────────
export const automationRules = mysqlTable("automation_rules", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(), // FK → userProfiles.id
  createdBy: int("createdBy").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  description: text("description"),
  triggerType: mysqlEnum("triggerType", ["scheduled", "keyword", "inactivity", "welcome"]).default("scheduled").notNull(),
  triggerValue: text("triggerValue"), // cron expression, keyword, or delay in minutes
  messageContent: text("messageContent").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  lastTriggered: timestamp("lastTriggered"),
  nextTrigger: timestamp("nextTrigger"),
  triggerCount: int("triggerCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AutomationRule = typeof automationRules.$inferSelect;
export type InsertAutomationRule = typeof automationRules.$inferInsert;

// ─── Chat Sessions ────────────────────────────────────────────────────────────
export const chatSessions = mysqlTable("chat_sessions", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  adminId: int("adminId").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  lastMessageAt: timestamp("lastMessageAt").defaultNow(),
  unreadCount: int("unreadCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;
