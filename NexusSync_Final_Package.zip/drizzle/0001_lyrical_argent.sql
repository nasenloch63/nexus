CREATE TABLE `automation_rules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`createdBy` int NOT NULL,
	`name` varchar(128) NOT NULL,
	`description` text,
	`triggerType` enum('scheduled','keyword','inactivity','welcome') NOT NULL DEFAULT 'scheduled',
	`triggerValue` text,
	`messageContent` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`lastTriggered` timestamp,
	`nextTrigger` timestamp,
	`triggerCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `automation_rules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`adminId` int NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`lastMessageAt` timestamp DEFAULT (now()),
	`unreadCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`senderId` int,
	`senderType` enum('admin','user','system','automated') NOT NULL DEFAULT 'admin',
	`content` text NOT NULL,
	`messageType` enum('text','image','file','template') NOT NULL DEFAULT 'text',
	`isRead` boolean NOT NULL DEFAULT false,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quick_reply_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`createdBy` int NOT NULL,
	`title` varchar(128) NOT NULL,
	`content` text NOT NULL,
	`category` varchar(64) DEFAULT 'general',
	`usageCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `quick_reply_templates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`createdBy` int NOT NULL,
	`displayName` varchar(128) NOT NULL,
	`username` varchar(64) NOT NULL,
	`email` varchar(320),
	`phone` varchar(32),
	`avatarUrl` text,
	`bio` text,
	`status` enum('active','inactive','banned') NOT NULL DEFAULT 'active',
	`platform` varchar(64) DEFAULT 'general',
	`tags` text,
	`isOnline` boolean NOT NULL DEFAULT false,
	`lastSeen` timestamp DEFAULT (now()),
	`totalMessages` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_profiles_username_unique` UNIQUE(`username`)
);
