# NexusSync — Schnellstart-Anleitung

## Was ist NexusSync?

NexusSync ist ein fortgeschrittenes Admin-Dashboard für die Verwaltung mehrerer Benutzerprofile mit Echtzeit-Chat, automatisierten Nachrichten und umfassenden Analytics.

**Hauptfeatures:**
- Multi-Profil-Verwaltung (CRUD-Operationen)
- Echtzeit-Chat mit Socket.io
- Automatisierte Nachrichtenplanung
- Analytics-Dashboard mit Diagrammen
- Dark/Light-Mode
- Globale Suche (⌘K)
- Rollenbasierte Zugriffskontrolle (RBAC)
- Mobile-first responsive UI

---

## Schnellstart (5 Minuten)

### 1. Abhängigkeiten installieren

```bash
npm install
# oder
pnpm install
```

### 2. Umgebungsvariablen konfigurieren

Erstellen Sie `.env.local`:

```env
DATABASE_URL=mongodb+srv://username:password@cluster.mongodb.net/nexussync
JWT_SECRET=your_secret_key_min_32_characters
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_NAME=Admin
OWNER_OPEN_ID=admin_open_id
VITE_FRONTEND_FORGE_API_KEY=your_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
```

### 3. Datenbankschema initialisieren

```bash
npm run db:push
```

### 4. Entwicklungsserver starten

```bash
npm run dev
```

Öffnen Sie http://localhost:3000

---

## Vercel-Deployment

Siehe **NexusSync_Anleitung.pdf** für detaillierte Anweisungen zu:
- MongoDB Atlas Setup
- Vercel Deployment
- Umgebungsvariablen-Konfiguration
- Troubleshooting

---

## Projektstruktur

```
nexussync/
├── client/                 # React Frontend
│   ├── src/
│   │   ├── pages/         # Seiten (Dashboard, Profiles, Chat, etc.)
│   │   ├── components/    # Wiederverwendbare Komponenten
│   │   ├── contexts/      # React Contexts (Theme, Auth)
│   │   ├── lib/           # Utilities (tRPC Client, etc.)
│   │   └── index.css      # Globale Styles
│   └── public/            # Statische Assets
├── server/                 # Express Backend
│   ├── routers/           # tRPC Router (profiles, messages, etc.)
│   ├── db.ts              # Datenbankqueries
│   └── _core/             # Framework-Code (OAuth, WebSocket, etc.)
├── drizzle/               # Datenbankschema
├── shared/                # Gemeinsame Types und Constants
├── package.json           # Dependencies
└── vite.config.ts         # Vite-Konfiguration
```

---

## Verfügbare Befehle

```bash
npm run dev        # Entwicklungsserver starten
npm run build      # Produktions-Build erstellen
npm start          # Produktions-Server starten
npm test           # Tests ausführen
npm run db:push    # Datenbankschema migrieren
npm run format     # Code formatieren
npm run check      # TypeScript-Check
```

---

## Technologie-Stack

| Layer | Technologie |
|---|---|
| Frontend | React 19, Tailwind CSS 4, Recharts, shadcn/ui |
| Backend | Express 4, tRPC 11, Socket.io |
| Datenbank | MongoDB (oder MySQL/TiDB) |
| ORM | Drizzle ORM |
| Testing | Vitest |
| Build | Vite 7 |
| Deployment | Vercel |

---

## Wichtige Dateien

- **`NexusSync_Anleitung.pdf`** — Vollständige deutsche Anleitung (Deployment, MongoDB, Troubleshooting)
- **`drizzle/schema.ts`** — Datenbankschema
- **`server/routers.ts`** — Alle tRPC-Router
- **`client/src/App.tsx`** — Routing und Layout
- **`client/src/components/NexusLayout.tsx`** — Hauptlayout mit Sidebar

---

## Support

Für Fragen oder Probleme:
1. Konsultieren Sie **NexusSync_Anleitung.pdf**
2. Überprüfen Sie die Logs: `npm run dev` zeigt Fehler in der Konsole
3. Prüfen Sie die MongoDB-Verbindung: `DATABASE_URL` muss korrekt sein

---

**Viel Erfolg mit NexusSync!**
